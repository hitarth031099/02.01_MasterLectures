package edu.stevens.cs548.clinic.service.dto;

public class PatientDtoFactory {
	
	public PatientDtoFactory() {
	}
	
	public PatientDto createPatientDto () {
		return new PatientDto();
	}
	
}
