package edu.stevens.cs548.clinic.data;

public class PatientFactory {
	
	public Patient createPatient() {
		return new Patient();
	}

}
