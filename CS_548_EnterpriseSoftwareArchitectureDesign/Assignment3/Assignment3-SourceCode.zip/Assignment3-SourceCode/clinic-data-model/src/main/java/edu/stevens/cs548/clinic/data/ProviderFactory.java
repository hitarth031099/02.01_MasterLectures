package edu.stevens.cs548.clinic.data;

public class ProviderFactory {
	
	public Provider createProvider() {
		return new Provider();
	}

}
