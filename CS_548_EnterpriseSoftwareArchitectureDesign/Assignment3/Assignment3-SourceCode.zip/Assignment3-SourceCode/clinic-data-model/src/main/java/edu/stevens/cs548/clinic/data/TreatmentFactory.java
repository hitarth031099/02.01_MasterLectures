package edu.stevens.cs548.clinic.data;

public class TreatmentFactory {
	
	public DrugTreatment createDrugTreatment() {
		return new DrugTreatment();
	}

}
